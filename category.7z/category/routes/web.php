<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DropDownController;
use App\Http\Controllers\DataCrudController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route::get('/', function () {
//     return view('category');
// });
 Route::get('/',[DropDownController::class,'index']);
 Route::post('/fetch-sub-cat',[DropDownController::class,'fetch_sub_cat']);


//  CRUD Controller

Route::post('/insert',[DataCrudController::class,'insert']);
Route::post('/insert-sub',[DataCrudController::class,'insert_sub']);