<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Category</title>
  </head>
  <body>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Add Category
    </button>
    <h1 class="alert alert-warning d-none" id="message"></h1>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            <div class="modal-body">
                <form id="form-id">
                    @csrf
                    <div class="mb-3">
                        <label for="country_name" class="form-label">Category</label>
                        <input type="text" name="name" class="form-control" id="country_name" aria-describedby="emailHelp" required>
                        
                    </div>
                
                    <button type="submit" name="submit" class="btn btn-primary" id="submit-form">Submit</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="close" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>
  
    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#subCatModal">
        Add Sub Category
    </button>
    <h1 class="alert alert-warning d-none" id="message"></h1>
    <!-- Modal -->
    <div class="modal fade" id="subCatModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            <div class="modal-body">
                <form id="sub-form-id">
                    @csrf
                    <select id="category-dropdown-insert" class="form-select" aria-label="Default select example">
            <option value="">Select Category</option>
            @foreach ($categories as $category)
            <option value="{{$category->id}}">{{$category->name}}</option>
            @endforeach
        </select>
        <br>
                    <div class="mb-3">
                        <label for="state_name" class="form-label">Sub Category</label>
                        <input type="text" name="name" class="form-control" id="state_name" aria-describedby="emailHelp" required>
                        
                    </div>

       
                
                    <button type="submit" name="submit" class="btn btn-primary" id="sub-cat-form">Save Sub Cat</button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" id="close" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
            </div>
        </div>
    </div>
    <div class="m-5">
        <select id="category-dropdown" class="form-select" aria-label="Default select example">
            <option value="">Select Category</option>
            @foreach ($categories as $category)
            <option value="{{$category->id}}">{{$category->name}}</option>
            @endforeach
        </select>

        <select id="sub-category-dropdown" class="form-select mt-3" aria-label="Default select example">
        </select>
    </div>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function (){
            $('#category-dropdown').on('change', function(){
                var categoryId = this.value;
                $('#sub-category-dropdown').html('');

                $.ajax({
                    url:"{{url('fetch-sub-cat')}}",
                    type:"POST",
                    data:{
                        category_id: categoryId,
                        _token:'{{csrf_token()}}'
                    },
                    dataType:'json',
                    success: function (result){
                        $('#sub-category-dropdown').html('<option value="">Select Sub Category</option>');
                        $.each(result.sub_cat, function (key, value){
                            $('#sub-category-dropdown').append('<option value="'+value.id+'">' + value.name +'</option>');
                        });
                    }

                });
            });

            // Insert Category
            $("#form-id").submit(function (e) {
                e.preventDefault();
                // alert('Test');
                $.ajax({
                    url:"{{url('insert')}}",
                    data:$("#form-id").serialize(),
                    dataType:'json',
                    type:"POST",
                    success:function(result){
                        // console.log(result);
                        $('#message').html(result.msg);
                        $('#message').removeClass('d-none');
                        $("#close").click();
                    },
                });
            });

            // Insert Sub Category
            $("#sub-form-id").submit(function (e) {
                e.preventDefault();
                var cat= $("#category-dropdown-insert").value;
                alert(cat);
                $.ajax({
                    url:"{{url('insert-sub')}}",
                    data:$("#sub-form-id").serialize(),
                    dataType:'json',
                    type:"POST",
                    success:function(result){
                        // console.log(result);
                        $('#message').html(result.msg);
                        $('#message').removeClass('d-none');
                        $("#close").click();
                    },
                });
            });
        });
    </script>
  </body>
</html>