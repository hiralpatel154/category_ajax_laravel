<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;

class DataCrudController extends Controller
{
    public function insert(Request $req){
        // return $req->post();

        $model = new Category();
        $model->name=$req->post('name');
        $model->save();
        return ['msg'=>"Data Inserted"];
    }
    public function insert_sub(Request $req){
        return $req->post();

        // $model = new Category();
        // $model->name=$req->post('name');
        // $model->save();
        // return ['msg'=>"Data Inserted"];
    }
}
