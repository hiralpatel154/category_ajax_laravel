<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Sub_category;

class DropDownController extends Controller
{
    public function index(){
        $data['categories'] = Category::get(["name","id"]);
        return view('category', $data);
    }
    public function fetch_sub_cat(Request $request){
        $data['sub_cat'] = Sub_category::where('category_id',$request->category_id)->get(['name','id']);
        return response()->json($data);
    }
}
