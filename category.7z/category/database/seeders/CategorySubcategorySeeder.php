<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Sub_category;

class CategorySubcategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Category 1 Data
        $category = Category::create(['name'=>'Category_1']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub_Category_1']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 2']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 3']);

        // Category 2 Data
        $category = Category::create(['name'=>'Category_2']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 1']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 2']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 3']);

        // Category 3 Data
        $category = Category::create(['name'=>'Category_3']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 1']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 2']);
        Sub_category::create(['category_id'=>$category->id,'name'=>'Sub Category 3']);
        
    }
}
